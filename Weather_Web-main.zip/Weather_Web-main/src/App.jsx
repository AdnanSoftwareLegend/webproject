import React from 'react'
import Temperature from './components/Temperature'

const App = () => {
  return (
    <div className='app'>
      <Temperature/>
      
    </div>
  )
}

export default App

